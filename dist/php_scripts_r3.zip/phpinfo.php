<?php
require_once("Android.php");

phpinfo();
