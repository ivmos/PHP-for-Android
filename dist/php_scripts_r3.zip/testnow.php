<?php
require_once("Android.php");
$droid = new Android();
//include("http://YOURHOST/yourfile.php.txt");
